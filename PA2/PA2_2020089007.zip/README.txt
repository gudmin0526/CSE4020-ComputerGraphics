한양대학교 컴퓨터소프트웨어학부 202089007 김형민

Changed:
  SimpleScene.py
  - catmullromSpline 추가
  - setRotate 추가
  - display 변경
  - initialize 변경
  - onMouseButton 매커니즘 변경
  - onMouseDrag vdrag 추가